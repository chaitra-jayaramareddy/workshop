### 1. Create a temporary file(notepad/texteditor) in your local machine to save key information such as,

Watson Discovery Information
1.			Username - apiKey
2.			API Key
3.			Discovery URL - (remove https://)
4.			Project ID

Watsonx Information
1.			URL (https://dataplatform.cloud.ibm.com)
2.			Project ID 
3.			API Key (IAM) 
